import { IMyDate } from './date.interface';

export interface IMyMarkedDates {
  dates: Array<IMyDate>;
  color: string;
}
