export const sbConfig = {
    serviceInstance: new Object()
};
export const sbItems = new Array<any>();

