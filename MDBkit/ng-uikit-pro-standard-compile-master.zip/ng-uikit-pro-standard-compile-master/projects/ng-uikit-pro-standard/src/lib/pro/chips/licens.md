https://www.npmjs.com/package/angular2-material-chips
