export interface Schema {
  project: string;
  animations: boolean;
  externalDependencies: boolean;
  additionalStyles: boolean;
}
