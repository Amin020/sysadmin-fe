import { ModuleWithProviders } from '@angular/core';
export { MDBBootstrapModule } from './free/mdb-free.module';
export { MDBBootstrapModulePro } from './pro/mdb-pro.module';
export declare class MDBRootModules {
}
export declare class MDBBootstrapModulesPro {
    static forRoot(): ModuleWithProviders<MDBRootModules>;
}
