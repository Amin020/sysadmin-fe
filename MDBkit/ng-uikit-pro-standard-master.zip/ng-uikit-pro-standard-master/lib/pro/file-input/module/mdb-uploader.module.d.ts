export declare class FileInputModule {
}
