export { RangeModule } from './range.module';
export { MdbRangeInputComponent } from './mdb-range.component';
export { MdbMultiRangeInputComponent } from './multi-range/mdb-multi-range.component';
