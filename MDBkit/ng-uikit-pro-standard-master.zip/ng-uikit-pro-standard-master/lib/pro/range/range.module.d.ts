export declare class RangeModule {
}
