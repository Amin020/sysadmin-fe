import { InjectionToken } from '@angular/core';
import { IMyOptions } from './interfaces/options.interface';
export declare const MDB_DATE_OPTIONS: InjectionToken<IMyOptions>;
