import { ModuleWithProviders } from '@angular/core';
export declare class AnimatedCardsModule {
    static forRoot(): ModuleWithProviders<AnimatedCardsModule>;
}
