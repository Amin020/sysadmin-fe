/**
 * returns coumputed style of given element

 */
export declare function computedStyle(element: string | HTMLElement, styleProp: string): string | any;
