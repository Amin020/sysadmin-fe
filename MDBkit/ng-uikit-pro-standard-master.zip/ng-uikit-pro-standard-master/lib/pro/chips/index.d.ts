export { CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR, MaterialChipsComponent } from './chips.component';
export { ChipsModule } from './chips.module';
