export declare class ChipsModule {
}
