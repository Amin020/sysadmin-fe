export { TIME_PIRCKER_VALUE_ACCESSOT, ClockPickerComponent } from './timepicker.component';
export { TimePickerModule } from './timepicker.module';
