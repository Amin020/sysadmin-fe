export declare const slideIn: any;
export declare const fadeIn: any;
export declare const slideOut: any;
export declare const flipState: any;
export declare const turnState: any;
export declare const iconsState: any;
export declare const socialsState: any;
export declare const flyInOut: any;
