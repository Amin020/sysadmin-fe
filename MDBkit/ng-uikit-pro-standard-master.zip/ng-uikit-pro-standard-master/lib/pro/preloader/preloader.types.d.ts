export declare type MDB_SPINNING_PRELOADER_TYPE = Element | HTMLDivElement;
