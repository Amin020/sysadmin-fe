import { MDB_SPINNING_PRELOADER_TYPE } from './preloader.types';
export declare class MDBSpinningPreloader {
    document: any;
    _container: MDB_SPINNING_PRELOADER_TYPE;
    static errorHandler(): void;
    constructor(document: any);
    start(): void;
    stop(): void;
    get container(): MDB_SPINNING_PRELOADER_TYPE;
    set container(element: MDB_SPINNING_PRELOADER_TYPE);
}
