declare const CONTAINER_CLASS_NAME = "spinning-preloader-container";
declare const COMPLETE_CLASS_NAME = "complete";
declare const CONTAINER_QUERY: string;
declare const CONTAINER_NAME: string;
export declare const TYPE_ERROR_CONTAINER_WAS_NOT_FOUND_MESSAGE: string;
export declare const EMULATE_ELEMENT_NAME = "div";
export { CONTAINER_QUERY, COMPLETE_CLASS_NAME, CONTAINER_CLASS_NAME, CONTAINER_NAME };
