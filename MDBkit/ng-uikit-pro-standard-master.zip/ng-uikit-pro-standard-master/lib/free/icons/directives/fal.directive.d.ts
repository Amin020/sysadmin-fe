import { ElementRef, Renderer2 } from '@angular/core';
export declare class FalDirective {
    private _el;
    private _r;
    constructor(_el: ElementRef, _r: Renderer2);
}
