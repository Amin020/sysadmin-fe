import { ElementRef, OnInit, Renderer2 } from '@angular/core';
import { Utils } from '../utils';
export declare class MdbIconComponent implements OnInit {
    private _el;
    private _renderer;
    icon: string;
    size: string;
    class: string;
    classInside: string;
    fab: boolean;
    far: boolean;
    fal: boolean;
    fad: boolean;
    fas: boolean;
    sizeClass: string;
    utils: Utils;
    constructor(_el: ElementRef, _renderer: Renderer2);
    ngOnInit(): void;
}
