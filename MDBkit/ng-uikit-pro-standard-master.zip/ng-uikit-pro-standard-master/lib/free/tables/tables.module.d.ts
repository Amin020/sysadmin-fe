export declare class TableModule {
}
