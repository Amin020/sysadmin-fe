export declare class BadgeModule {
}
