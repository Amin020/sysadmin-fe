export declare class MdbBreadcrumbComponent {
    customClass: string;
    textTransform: string;
}
