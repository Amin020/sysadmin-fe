import { ElementRef, OnInit, Renderer2 } from '@angular/core';
export declare class MdbCardComponent implements OnInit {
    private _el;
    private _r;
    class: string;
    cascade: boolean;
    wider: boolean;
    imageBackground: string;
    card: ElementRef;
    set narrower(narrower: boolean);
    set reverse(reverse: boolean);
    set dark(dark: boolean);
    set bgColor(color: string);
    set borderColor(color: string);
    constructor(_el: ElementRef, _r: Renderer2);
    ngOnInit(): void;
}
