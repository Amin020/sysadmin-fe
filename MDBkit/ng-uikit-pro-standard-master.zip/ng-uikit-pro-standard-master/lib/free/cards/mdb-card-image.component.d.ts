export declare class MdbCardImageComponent {
    src: string;
    alt: string;
}
