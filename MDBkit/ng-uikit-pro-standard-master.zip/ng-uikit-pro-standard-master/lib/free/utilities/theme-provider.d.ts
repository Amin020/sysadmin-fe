export declare function setTheme(theme: 'bs3' | 'bs4'): void;
export declare function isBs3(): boolean;
