export declare class LogoComponent {
}
