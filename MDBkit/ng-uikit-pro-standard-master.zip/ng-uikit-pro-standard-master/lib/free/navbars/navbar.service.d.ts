import { Observable } from 'rxjs';
export declare class NavbarService {
    private navbarLinkClicks;
    getNavbarLinkClicks(): Observable<any>;
    setNavbarLinkClicks(): void;
}
