import { ModuleWithProviders } from '@angular/core';
export declare class DropdownModule {
    static forRoot(config?: any): ModuleWithProviders<DropdownModule>;
}
