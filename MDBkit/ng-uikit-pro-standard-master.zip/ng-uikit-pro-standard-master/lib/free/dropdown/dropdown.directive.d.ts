import { ElementRef, EmbeddedViewRef, EventEmitter, OnDestroy, OnInit, Renderer2, ViewContainerRef, ChangeDetectorRef } from '@angular/core';
import { Subscription } from 'rxjs';
import { ComponentLoader } from '../utils/component-loader/component-loader.class';
import { ComponentLoaderFactory } from '../utils/component-loader/component-loader.factory';
import { BsDropdownConfig } from './dropdown.config';
import { BsDropdownContainerComponent } from './dropdown-container.component';
import { BsDropdownState } from './dropdown.state';
import { BsDropdownMenuDirective } from './dropdown-menu.directive';
export declare class BsDropdownDirective implements OnInit, OnDestroy {
    private _elementRef;
    private _renderer;
    private _viewContainerRef;
    private _cis;
    private _config;
    private _state;
    private cdRef;
    /**
     * Placement of a popover. Accepts: "top", "bottom", "left", "right"
     */
    placement: string;
    /**
     * Specifies events that should trigger. Supports a space separated list of
     * event names.
     */
    triggers: string;
    /**
     * A selector specifying the element the popover should be appended to.
     * Currently only supports "body".
     */
    container: string;
    dropup: boolean;
    dropupDefault: boolean;
    dynamicPosition: boolean;
    /**
     * This attribute indicates that the dropdown should be opened upwards
     */
    get isDropup(): true | undefined;
    /**
     * Indicates that dropdown will be closed on item or document click,
     * and after pressing ESC
     */
    set autoClose(value: boolean);
    get autoClose(): boolean;
    /**
     * Disables dropdown toggle and hides dropdown menu if opened
     */
    set isDisabled(value: boolean);
    get isDisabled(): boolean;
    /**
     * Returns whether or not the popover is currently being shown
     */
    get isOpen(): boolean;
    set isOpen(value: boolean);
    /**
     * Emits an event when isOpen change
     */
    isOpenChange: EventEmitter<any>;
    /**
     * Emits an event when the popover is shown
     */
    onShown: EventEmitter<any>;
    shown: EventEmitter<any>;
    /**
     * Emits an event when the popover is hidden
     */
    onHidden: EventEmitter<any>;
    hidden: EventEmitter<any>;
    private _destroy$;
    get isBs4(): boolean;
    _isInlineOpen: boolean;
    _showInline: boolean;
    _inlinedMenu: EmbeddedViewRef<BsDropdownMenuDirective>;
    _isDisabled: boolean;
    _dropdown: ComponentLoader<BsDropdownContainerComponent>;
    _dropup: boolean;
    _subscriptions: Subscription[];
    _isInited: boolean;
    _isDropupDefault: boolean;
    constructor(_elementRef: ElementRef, _renderer: Renderer2, _viewContainerRef: ViewContainerRef, _cis: ComponentLoaderFactory, _config: BsDropdownConfig, _state: BsDropdownState, cdRef: ChangeDetectorRef);
    ngOnInit(): void;
    /**
     * Opens an element’s popover. This is considered a “manual” triggering of
     * the popover.
     */
    show(): void;
    /**
     * Closes an element’s popover. This is considered a “manual” triggering of
     * the popover.
     */
    hide(): void;
    /**
     * Toggles an element’s popover. This is considered a “manual” triggering of
     * the popover.
     */
    toggle(value?: boolean): void;
    ngOnDestroy(): void;
}
