import { ModuleWithProviders } from '@angular/core';
export declare class CarouselModule {
    static forRoot(): ModuleWithProviders<CarouselModule>;
}
