import { Data } from '../models/index';
export declare function preventOverflow(data: Data): Data;
