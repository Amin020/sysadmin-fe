import { Data } from '../models/index';
export declare function arrow(data: Data): Data;
