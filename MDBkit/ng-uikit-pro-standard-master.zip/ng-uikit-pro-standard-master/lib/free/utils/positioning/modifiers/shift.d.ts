import { Data } from '../models/index';
export declare function shift(data: Data): Data;
