export declare function getOffsetParent(element: any): any;
