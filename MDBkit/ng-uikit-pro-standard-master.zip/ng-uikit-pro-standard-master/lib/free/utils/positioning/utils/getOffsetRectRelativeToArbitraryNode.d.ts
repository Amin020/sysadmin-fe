export declare function getOffsetRectRelativeToArbitraryNode(children: HTMLElement, parent: HTMLElement, fixedPosition?: boolean): any;
