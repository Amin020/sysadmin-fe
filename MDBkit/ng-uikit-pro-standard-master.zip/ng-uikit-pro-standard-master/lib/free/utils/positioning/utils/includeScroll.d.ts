export declare function includeScroll(rect: any, element: HTMLElement, subtract?: boolean): any;
