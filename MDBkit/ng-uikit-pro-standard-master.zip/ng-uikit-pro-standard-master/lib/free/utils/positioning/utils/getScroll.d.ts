/**
 * Gets the scroll value of the given element in the given side (top and left)
 */
export declare function getScroll(element: any, side?: string): any;
