/**
 * Helper to detect borders of a given element
 */
export declare function getBordersSize(styles: CSSStyleDeclaration, axis: string): number;
