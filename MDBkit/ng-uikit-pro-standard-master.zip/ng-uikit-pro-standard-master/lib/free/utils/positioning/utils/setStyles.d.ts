/**
 * Set the style to the given popper
 */
import { Renderer2 } from '@angular/core';
export declare function setStyles(element: HTMLElement, styles: any, renderer?: Renderer2): void;
