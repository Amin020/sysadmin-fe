/**
 * Get CSS computed property of the given element
 */
export declare function getStyleComputedProperty(element: any, property?: string): any;
