/**
 * Given element offsets, generate an output similar to getBoundingClientRect
 */
import { Offsets } from '../models/index';
export declare function getClientRect(offsets: any): Offsets;
