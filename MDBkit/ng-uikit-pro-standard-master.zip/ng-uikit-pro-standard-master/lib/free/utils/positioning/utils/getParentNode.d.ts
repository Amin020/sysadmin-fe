/**
 * Returns the parentNode or the host of the element
 */
export declare function getParentNode(element: any): any;
