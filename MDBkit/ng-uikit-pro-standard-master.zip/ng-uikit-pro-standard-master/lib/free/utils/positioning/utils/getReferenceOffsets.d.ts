import { Offsets } from '../models/index';
export declare function getReferenceOffsets(target: HTMLElement, host: HTMLElement, fixedPosition?: any): Offsets;
