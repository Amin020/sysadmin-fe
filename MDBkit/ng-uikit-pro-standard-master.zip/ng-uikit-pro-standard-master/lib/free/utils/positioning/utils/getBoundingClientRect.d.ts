export declare function getBoundingClientRect(element: HTMLElement): any;
