/**
 * Finds the root node (document, shadowDOM root) of the given element
 */
export declare function getRoot(node: Node): any;
