export declare function getBoundaries(target: any, host: HTMLElement, padding: number | undefined, boundariesElement: string, fixedPosition?: boolean): any;
