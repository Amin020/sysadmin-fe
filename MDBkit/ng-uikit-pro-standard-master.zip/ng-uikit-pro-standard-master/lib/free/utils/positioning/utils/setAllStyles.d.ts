/**
 * Set the style to the given popper
 */
import { Renderer2 } from '@angular/core';
import { Data } from '../models/index';
export declare function setAllStyles(data: Data, renderer?: Renderer2): void;
