import { Tree } from '@angular-devkit/schematics';
export declare function addPackageToPackageJson(tree: Tree, pkg: string, version: string): Tree;
